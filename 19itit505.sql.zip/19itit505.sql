-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Jun 21, 2021 at 06:02 PM
-- Server version: 5.7.32
-- PHP Version: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `19itit505`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_id` int(11) NOT NULL,
  `f_name` varchar(30) NOT NULL,
  `L_name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `f_name`, `L_name`, `email`, `password`) VALUES
(1, 'Madhawa', 'Monarawila', 'madawa@gmail.com', 'carrot'),
(2, 'Lahiru', 'Munasinghe', 'lahiru123@gmail.com', 'apple'),
(3, 'Geethaka', 'Nawarathna', 'geethaka@gmail.com', 'ryzen'),
(4, 'Nuwan', 'Wijeweera', 'nuwan1@gmail.com', 'dead');

-- --------------------------------------------------------

--
-- Table structure for table `car_info`
--

CREATE TABLE `car_info` (
  `car_id` int(11) NOT NULL,
  `car_member_id` int(11) NOT NULL,
  `brand` varchar(20) NOT NULL,
  `model` varchar(20) NOT NULL,
  `car_condition` varchar(20) NOT NULL,
  `price` int(11) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `car_info`
--

INSERT INTO `car_info` (`car_id`, `car_member_id`, `brand`, `model`, `car_condition`, `price`, `description`, `image`) VALUES
(1, 1, 'Ferrari', '458', 'Used', 40000000, 'The Ferrari 458 Italia (Type F142) is a mid-engine sports car produced by the Italian automobile manufacturer Ferrari.', 'image/ferrari458.jpg'),
(2, 2, 'Ford', 'GT', 'Used', 99000000, 'The Ford GT is a mid-engine two-seater supercar by Ford. 2005 model year in conjunction with the company\'s 2003 centenary.', 'image/fordgt.jpg'),
(3, 3, 'Porsche', 'GT2-RS', 'Used', 58000000, 'lightweight sports car with a 3.8-liter flat-six that cranks out 700 horsepower.', 'image/porschegt2.jpg'),
(4, 1, 'Tesla', 'Model 3 P90D', 'Used', 21000000, 'The P90D combines a front axle power of 259 horsepower (193 kW) and rear axle power of 503 horsepower (375 kW) for a 0–60 in 2.8 seconds.', 'image/teslas.jpg'),
(6, 1, 'Toyota', 'Supra', 'Used', 30000000, '335BHP, gas engine, 2 seater sport car. 2020 version, automatic transmission.', 'image/toyotasupra.jpg'),
(14, 8, 'Cadillac', 'The One', 'Used', 290000000, 'Not have been used by US presidents. collection edition. armoured plate. known as The Beast.', 'image/cadilllacbeawst.jpg'),
(45, 26, 'McLaren', '765LT', 'Brand New', 30000000, 'New car. One of the Mclaren\'s most beautiful cars.', 'image/mclaren_765lt_2021-2560x1440.jpg'),
(50, 3, 'Porsche', '918', 'Registered', 90000000, 'mid-engine plug-in hybrid sports car. 4.6 L (4,593 cc) Porsche MR6 V8 Engine', 'image/porsche2.jpg'),
(51, 3, 'Porsche', '917', 'Used', 120000000, 'Type 912 flat-12 engine of 4.5, 4.9, or 5 litres, the 917/30 Can-Am variant was capable of a 0-62 mph (100 km/h) time of 2.3 seconds.', 'image/porsche-917k.jpg'),
(52, 8, 'Bugatti', 'Chiron', 'Unregistered', 200000000, '8.0 L (488 cu in) quad-turbocharged W16. 1,479 hp. 482.80 km/h', 'image/bugatti-chiron-pur-sport.jpg'),
(53, 2, 'Ferrari', '458', 'Unregistered', 55060000, '4.5 L Ferrari F136 F V8. 562 hp. 7-speed dual-clutch automatic gearbox by Getrag.', 'image/f458.jpg'),
(54, 2, 'Ferrari', 'LaFerrari', 'Unregistered', 250000000, 'limited production hybrid sports car. V12, 950 hp, 7-speed dual-clutch automatic.', 'image/Laferrari.jpg'),
(55, 2, 'Ford', 'F150 Raptor', 'Used', 10000000, 'uses a 6.2 L V8 engine rated at 500 hp (370 kW). upgraded suspension.', 'image/f150.jpg'),
(56, 2, 'Ford', 'Mustang RTR', 'Used', 18000000, ' 5.0-liter V8 with 460 horsepower and 420 pound-feet of torque.', 'image/fmustang.jpg'),
(57, 2, 'Lamborghini', 'Aventador', 'Registered', 200000000, '759.01bhp at 8500rpm. 6498 cc . It is available with the Automatic transmission.', 'image/avantador.jpg'),
(58, 7, 'Tesla', 'Model Y', 'Registered', 35000000, 'Weight. 4,416 lbs · Max Cargo Volume. 68 cu ft · Top Speed. 155 mph · Displays. 15\" Center Touchscreen · Supercharging. Pay Per Use · Warranty. SUV', 'image/modely.jpg'),
(59, 7, 'Tesla', 'Model S', 'Used', 10000000, '100 kWH, The Tesla Model S is an all-electric five-door liftback sedan produced by Tesla, Inc. It was introduced on June 22, 2012.', 'image/modelS.jpg'),
(60, 42, 'Lamborghini', 'Veneno', 'Unregistered', 200000000, 'V12, 60°, MPI. MAX. POWER. 750 CV (552 kW) @ 8.400 rpm. WEIGHT-TO-POWER RATIO. 1,99 kg/CV', 'image/veneno_555.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `car_owners`
--

CREATE TABLE `car_owners` (
  `member_id` int(11) NOT NULL,
  `f_name` varchar(30) NOT NULL,
  `l_name` varchar(30) NOT NULL,
  `nic` varchar(20) NOT NULL,
  `city` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `car_owners`
--

INSERT INTO `car_owners` (`member_id`, `f_name`, `l_name`, `nic`, `city`, `email`, `password`) VALUES
(1, 'James', 'May', '873534183V', 'London', 'james@gmail.com', 'james123'),
(2, 'Jeremy', 'Clarkson', '873534195V', 'Doncaster', 'jeremy@gmail.com', 'jeremy123'),
(3, 'Richard', 'Hammond', '873534206V', 'Birmingham', 'richard@gmail.com', 'richard123'),
(4, 'Louis', 'Hamilton', '905556478V', 'London', 'louis@gmail.com', 'louis123'),
(7, 'max', 'verstappen', '983334182V', 'Paris', 'max@gmail.com', 'max123'),
(8, 'Joe', 'Biden', '877462345V', 'Washington', 'joe@gmail.com', 'joe123'),
(25, 'Madhawa', 'Monarawila', '973334182V', 'Medawala', 'madhawa.spn@gmail.com', 'madhawa123'),
(26, 'Amal', 'Peiris', '974567425V', 'Katugastota', 'amal@gmail.com', 'amal123'),
(41, 'Donald', 'Trump', '574328876V', 'NewYork', 'donald@gmail.com', 'donald123'),
(42, 'Sheldon', 'Cooper', '896545436V', 'Pasedina', 'sheldon@gmail.com', 'sheldon123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `car_info`
--
ALTER TABLE `car_info`
  ADD PRIMARY KEY (`car_id`),
  ADD KEY `fk_to_memberid` (`car_member_id`);

--
-- Indexes for table `car_owners`
--
ALTER TABLE `car_owners`
  ADD PRIMARY KEY (`member_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `car_info`
--
ALTER TABLE `car_info`
  MODIFY `car_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `car_owners`
--
ALTER TABLE `car_owners`
  MODIFY `member_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `car_info`
--
ALTER TABLE `car_info`
  ADD CONSTRAINT `fk_to_memberid` FOREIGN KEY (`car_member_id`) REFERENCES `car_owners` (`member_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
